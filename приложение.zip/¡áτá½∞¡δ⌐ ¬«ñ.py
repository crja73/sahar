import os
import random
from os import path
import sys
import PyQt5
from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5 import uic, QtCore
from PyQt5.QtGui import QPixmap
from random import randrange
from PyQt5.QtWidgets import QInputDialog, QLineEdit
import time
import datetime
#import pyglet
#
#  
#sound = pyglet.media.load('фон.wav', streaming=False)
#sound.play()
#pyglet.app.run()



tim = time.strftime("%Y-%m-%d|%H|%M|%S", time.localtime())
r = tim.split('|')
if r[1] == 23 and r[2] == 59 and r[3] == 59:
    f = open('все приемы пищи', 'a')
    f.truncate()
    
    
    
class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('sahar.ui',self)

        f = open("данные.txt", 'r')
        lines = f.readlines()
        if len(lines) == 0:
            j, okBtnPressed = QInputDialog.getItem(self, "выберите коэфициент", 'выберите коэфициент для завтрака:',('1', '1.1', '1.2','1.3', '1.4', '1.5', '1.6', '1.7', '1.8', '1.9', '2'))

            if okBtnPressed:
                breakfast = j
                g = open("данные.txt", 'a')
                g.write(j)

            x, okBtnPressed = QInputDialog.getItem(self, "выберите коэфициент", 'выберите коэфициент для обеда:',('1', '1.1', '1.2','1.3', '1.4', '1.5', '1.6', '1.7', '1.8', '1.9', '2'))

            if okBtnPressed:
                lunch = x
                g = open("данные.txt", 'a')
                g.write(x)


            y, okBtnPressed = QInputDialog.getItem(self, "выберите коэфициент", 'выберите коэфициент для ужина:',('1', '1.1', '1.2','1.3', '1.4', '1.5', '1.6', '1.7', '1.8', '1.9', '2'))

            if okBtnPressed:
                diner = y
                g = open("данные.txt", 'a')
                g.write(y)


        self.pushButton.clicked.connect(self.second)
        self.pushButton_2.clicked.connect(self.third)
        self.pushButton_3.clicked.connect(self.fourth)

   

    def second(self):
    	self.second_form = SecondForm()
    	self.second_form.show()

    def third(self):
    	self.third_form = ThirdForm()
    	self.third_form.show()

    def fourth(self):
    	self.fourth_form = FourthForm()
    	self.fourth_form.show()


class SecondForm(QMainWindow):
    def __init__(self):
        super().__init__()
        self.spis = []
        uic.loadUi('second.ui', self)
        self.pushButton7.clicked.connect(self.do)
        self.pushButton8.clicked.connect(self.products)
        self.pushButton_9.clicked.connect(self.calculation)
        self.pushButton_j.clicked.connect(self.pisha)
        


    def do(self):
        self.spis.append(self.lineEdit.text())
        if (self.spis[-1]) == '':
            self.label_2.setText('Ошибка, введите уровень сахара!')
        elif float(self.spis[-1]) < 3.5:
            self.label_2.setText('СЛИШКОМ НИЗКИЙ УРОВЕНЬ САХАРА, для нормы съешьте на {} единицы'.format(3.5 - float(self.spis[-1])))
        elif float(self.spis[-1]) > 6.1:
            self.label_2.setText('СЛИШКОМ ВЫСОКИЙ УРОВЕНЬ САХАРА, для нормы вколите еще {} единиц инсулина'.format(float(self.spis[-1]) - 6.5))
        elif float(self.spis[-1]) == 3.5:
            self.label_2.setText('Пониженный уровень сахара')
        elif float(self.spis[-1]) == 6.1:
            self.label_2.setText('Повышенный уровень сахара, для нормы')
        elif float(self.spis[-1]) < 6.1 and float(self.spis[-1]) > 3.5:
            self.label_2.setText('                                                           В пределах нормы')

    def products(self):
        j, okBtnPressed = QInputDialog.getItem(self, "выберите коэфициент", 'выберите коэфициент для завтрака:',('Брынза | 0,0', 'Йогурт 1.5% жирности | 3.5', 'Кефир 0% жирность | 3.8', 'Кефир 3,2% жирность | 4.1', 'Молоко 3,2% жирность | 4.7', 
            'Молоко сухое цельное | 39.4', 'Молоко сгущеное с сахаром | 56.0', 'Простокваша | 4.1', 'Ряженка | 4.1', 'Сливки 10% | 4.0 ', 'Сливки 20% | 3.6', 'Сметана 10% | 2.9', 'Сметана 20% | 3.2', 'Сырки и масса творожные особые | 27.5', 'Сыр российский | 0.0', 
            'Сыр голландский | 0.0', 'Творог жирный | 1.3', 'Творог обезжиреный | 1.5'))



        if okBtnPressed:
            breakfast = j
            if breakfast != '':
                self.name = breakfast.split("|")
                
                self.label_4.setText(self.name[0])
                self.spis.append(self.lineEdit_2.text())
            else:
                pass
        

    def calculation(self):
        ap = time.strftime("%Y-%m-%d|%H.%M.%S", time.localtime())
        a = str(float(self.name[1]) * int(self.spis[-1]))
        self.label_5.setText(a)
        fi = open("все приемы пищи.txt", 'w')
        fi.write('{} - {}'.format(a, ap))
    
    
    def pisha(self):
        h = open("все приемы пищи.txt", 'a')
        a = time.strftime("%Y-%m-%d|%H.%M.%S", time.localtime())
        j, okBtnPressed = QInputDialog.getItem(self, "прием пищи", 'укажите, какой это прием пищи:',('завтрак', 'обед', 'ужин'))
        h.write(j)
        h.write('\n')
        
        

class ThirdForm(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('third.ui', self)
        g = open("все приемы пищи.txt", 'r')
        lines = g.readlines()
        for line in lines:
            if 'завтрак' in line:
                self.table.appendPlainText(line)
            elif 'обед' in line:
                self.table2.appendPlainText(line)
            else:
                self.table3.appendPlainText(line)
                
                

class FourthForm(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('fourth.ui', self)
        self.pushButton_dann.clicked.connect(self.dannie)
    
    
    def dannie(self):
        j, okBtnPressed = QInputDialog.getItem(self, "типо форматирования", '',('сбросить до заводских настроек', 'удалить данные о питании за сегодня', 'сбросить только средние дозы инсулина'))
        
        if okBtnPressed:
            if j == 'сбросить до заводских настроек':
                f =open('все приемы пищи.txt', 'w')
                f.truncate()
                f.close()
                g = open('данные.txt', 'w')
                g.truncate()
                g.close()
                
            elif j == 'удалить данные о питании за сегодня':
                h = open('все приемы пищи.txt', 'w')
                h.truncate()
                h.close()
                
            elif j == 'сбросить только средние дозы инсулина':
                i = open('данные.txt', 'w')
                i.truncate()
                i.close()
            
        




ti = time.strftime("%Y-%m-%d|%H.%M.%S", time.localtime())

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec())